<footer class="bg-success text-white d-flex justify-content-center align-items-center p-3 border-top border-2 mt-auto">
    <span>© 2021 Logrocho, Valentín Georgian Castravete</span>
</footer>