<footer class="bg-dark text-white d-flex flex-wrap justify-content-center align-items-center p-3 border-top border-2 mt-auto">
    <span>© 2021 Logrocho, Valentín Georgian Castravete</span>
</footer>