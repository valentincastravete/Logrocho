Buenas Raúl,

Para probar el primer punto (imágenes), puedes acceder a un bar individual o un pincho individual, selecionar una o varias imágenes y darle al botón de Guardar.

Para lo de las reseñas y me gustas, en la colección de postman tienes las acciones para modificar o eliminar una reseña de un usuario y eliminar los me gustas de un usuario a una reseña.
Las reseñas y me gustas de un usuario se elminan en cascada si el usuario se elimina, puedes probar a utilizar la llamada de postman de baja de usuario.

Cualquier duda, por Teams y si ves que no contesto en una hora, porfavor envíame un correo a valentincastravete@gmail.com.

Un saludo, Valentín