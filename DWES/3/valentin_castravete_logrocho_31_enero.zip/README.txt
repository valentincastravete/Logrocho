Buenas Raúl,

Te escribo esto para comentarte que te he exportado una collección desde Postman con las peticiones ya preparadas. Solo tendrás que cambiar la URL.

También te quiero comentar que en las funciones de los controladores no pido nada, sino que lo busco en los argumentos de la petición POST/GET.

Cualquier duda, coméntame por Teams, estaré atento.

Gracias

PD: te he vuelto a pasar el sql para recrear con los cambios aplicados