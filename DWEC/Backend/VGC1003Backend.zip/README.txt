Desde el listado, para acceder a la ficha de un registro, pulsar en el id.
Desde la ficha, modificar datos y pulsar guardar para actualizar en base de datos.
Desde la ficha, pulsar crear para limpiar datos y al rellenar, pulsar guardar para crearlo en base de datos.
La contraseña de mi cuenta (valentincastravete@gmail.com) para acceder al backend es "admin".

No hay ficha de pincho, valoracion ni usuario funcional, solo bar.
No se pueden asociar imagenes.
Hay paginacion, mostrar/ocutlar columnas y ordenacion en todos los listados.